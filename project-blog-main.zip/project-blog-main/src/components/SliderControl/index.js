export * from './SliderControl';
export { default } from './SliderControl';
