export * from './CircularColorsDemo';
export { default } from './CircularColorsDemo';
