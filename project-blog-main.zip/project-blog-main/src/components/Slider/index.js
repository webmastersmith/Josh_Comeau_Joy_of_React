export * from './Slider';
export { default } from './Slider';
